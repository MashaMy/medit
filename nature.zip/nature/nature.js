let timerID;
const buttonPlay = document.querySelector('#countdown'); 
buttonPlay.addEventListener("click", function() {
    timerID = setInterval(timer, 1000);
})

const buttonStop = document.querySelector('#stop'); 
buttonStop.addEventListener("click", function() {
    stopTimer();
});

const time = 30;
let amountTime = time * 60;

function timer() {
    document.querySelector('#countdown').style.display = "none";
    document.querySelector('#stop').style.display = "block";
    document.querySelector('audio').play();
    document.querySelector('video').play();
    let minutes = Math.floor(amountTime/60);
    let seconds = amountTime%60;

    if(seconds < 10) {
        seconds = "0" + seconds;
    }

    buttonStop.textContent = `${minutes} : ${seconds}`;
    buttonPlay.textContent = `${minutes} : ${seconds}`;
    amountTime--;

    if(amountTime < 0) {
       amountTime = 0;
       stopTimer()
    }

}

function stopTimer() {
         clearInterval(timerID);
         document.querySelector('#countdown').style.display = "block";
         document.querySelector('#stop').style.display = "none";
         document.querySelector('audio').pause();
         document.querySelector('video').pause();
      }
